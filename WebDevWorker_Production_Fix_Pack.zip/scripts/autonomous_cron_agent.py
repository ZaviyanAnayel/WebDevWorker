import os
import json
import urllib.request
import re
import datetime

GROQ_API_KEY = os.environ.get('GROQ_API_KEY', '')
TOOLS_DB_PATH = 'scripts/tools_db.json'
ARTICLES_DIR = 'articles'
SITEMAP_PATH = 'sitemap.xml'
SITE_URL = 'https://webdevworker.com'

def call_groq(prompt):
    if not GROQ_API_KEY:
        print("GROQ_API_KEY not set in environment.")
        return None
    url = "https://api.groq.com/openai/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {GROQ_API_KEY}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": "qwen-2.5-coder-32b",
        "messages": [
            {"role": "system", "content": "You are an elite developer educator and technical SEO architect writing 2,500+ words in-depth master guides."},
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.3,
        "max_tokens": 4000
    }
    try:
        req = urllib.request.Request(url, data=json.dumps(payload).encode('utf-8'), headers=headers)
        with urllib.request.urlopen(req, timeout=90) as res:
            data = json.loads(res.read().decode('utf-8'))
            return data['choices'][0]['message']['content']
    except Exception as e:
        print(f"Groq API error: {e}")
        return None

def update_sitemap(new_url):
    if not os.path.exists(SITEMAP_PATH):
        return
    try:
        with open(SITEMAP_PATH, 'r') as f:
            content = f.read()
        if new_url in content:
            return
        today = datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%d')
        new_entry = f"  <url>\n    <loc>{new_url}</loc>\n    <lastmod>{today}</lastmod>\n    <changefreq>weekly</changefreq>\n    <priority>0.8</priority>\n  </url>\n</urlset>"
        content = content.replace('</urlset>', new_entry)
        with open(SITEMAP_PATH, 'w') as f:
            f.write(content)
        print(f"Updated sitemap with {new_url}")
    except Exception as e:
        print(f"Error updating sitemap: {e}")

def main():
    print("Starting Autonomous SEO Agent...")
    if not os.path.exists(ARTICLES_DIR):
        os.makedirs(ARTICLES_DIR, exist_ok=True)
    print("Autonomous agent execution completed.")

if __name__ == "__main__":
    main()
