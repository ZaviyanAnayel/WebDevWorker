import urllib.request
import json
import xml.etree.ElementTree as ET
import os

HOST = "webdevworker.com"
KEY = "e7c2a4b89f014d5e82a3c7b6d1e49f82"
KEY_LOCATION = f"https://{HOST}/{KEY}.txt"
SITEMAP_PATH = "sitemap.xml"

ENDPOINTS = [
    "https://api.indexnow.org/indexnow",
    "https://yandex.com/indexnow"
]

def get_urls_from_sitemap():
    urls = []
    if not os.path.exists(SITEMAP_PATH):
        return urls
    try:
        tree = ET.parse(SITEMAP_PATH)
        root = tree.getroot()
        namespace = {'ns': 'http://www.sitemaps.org/schemas/sitemap/0.9'}
        for loc in root.findall('.//ns:loc', namespace):
            if loc.text:
                urls.append(loc.text.strip())
    except Exception as e:
        print(f"Error reading sitemap: {e}")
    return urls

def submit_indexnow():
    url_list = get_urls_from_sitemap()
    if not url_list:
        print("No URLs found to submit.")
        return

    payload = {
        "host": HOST,
        "key": KEY,
        "keyLocation": KEY_LOCATION,
        "urlList": url_list[:10000]
    }
    data = json.dumps(payload).encode('utf-8')

    for endpoint in ENDPOINTS:
        try:
            req = urllib.request.Request(
                endpoint,
                data=data,
                headers={"Content-Type": "application/json; charset=utf-8"}
            )
            with urllib.request.urlopen(req, timeout=15) as response:
                print(f"✓ IndexNow [{endpoint}] response: {response.status}")
        except Exception as err:
            print(f"IndexNow submission to {endpoint} failed: {err}")

if __name__ == "__main__":
    submit_indexnow()
