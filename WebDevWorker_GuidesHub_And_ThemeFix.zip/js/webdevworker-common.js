/**
 * WebDevWorker — Universal Production Engine V30
 * Complete Theme Sync (Dark/Light), Guides Navigation, and Overlay Click Fix.
 */
(function() {
  'use strict';

  // 1. Resilient Multi-Key Theme Sync
  function initTheme() {
    var saved = localStorage.getItem('webdevworker_theme') || 
                localStorage.getItem('theme') || 
                localStorage.getItem('calcworker_theme') || 
                'dark';

    // Apply attribute immediately
    document.documentElement.setAttribute('data-theme', saved);
    if (document.body) {
      document.body.setAttribute('data-theme', saved);
    }

    // Keep all legacy keys in sync so NO tool ever reverts
    localStorage.setItem('webdevworker_theme', saved);
    localStorage.setItem('theme', saved);

    var btn = document.getElementById('themeToggleBtn');
    if (btn) {
      updateThemeBtnUI(btn, saved);

      btn.onclick = function(e) {
        if (e) e.preventDefault();
        var current = document.documentElement.getAttribute('data-theme') || 'dark';
        var next = (current === 'dark') ? 'light' : 'dark';

        document.documentElement.setAttribute('data-theme', next);
        if (document.body) document.body.setAttribute('data-theme', next);

        localStorage.setItem('webdevworker_theme', next);
        localStorage.setItem('theme', next);
        localStorage.setItem('calcworker_theme', next);

        updateThemeBtnUI(btn, next);
      };
    }
  }

  function updateThemeBtnUI(btn, theme) {
    if (theme === 'dark') {
      btn.innerHTML = '<span style="font-size:14px;">☀️</span> <span class="btn-label">Light</span>';
      btn.setAttribute('aria-label', 'Switch to Light Mode');
    } else {
      btn.innerHTML = '<span style="font-size:14px;">🌙</span> <span class="btn-label">Dark</span>';
      btn.setAttribute('aria-label', 'Switch to Dark Mode');
    }
  }

  // 2. Mobile Drawer Navigation & Backdrop Click-Through Fix
  function initMobileDrawer() {
    var btn = document.getElementById('hamburgerBtn');
    var sidebar = document.getElementById('sidebar');
    var backdrop = document.getElementById('sidebarBackdrop');

    if (backdrop) {
      backdrop.style.pointerEvents = 'none';
      backdrop.style.opacity = '0';
    }

    if (btn && sidebar && backdrop) {
      btn.onclick = function(e) {
        if (e) e.stopPropagation();
        var isOpen = sidebar.classList.toggle('open');
        backdrop.classList.toggle('open', isOpen);
        backdrop.style.pointerEvents = isOpen ? 'auto' : 'none';
        backdrop.style.opacity = isOpen ? '1' : '0';
      };
      backdrop.onclick = function() {
        sidebar.classList.remove('open');
        backdrop.classList.remove('open');
        backdrop.style.pointerEvents = 'none';
        backdrop.style.opacity = '0';
      };
    }
  }

  // 3. Silent Service Worker Registration (No rogue auto-reloads)
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', function() {
      navigator.serviceWorker.register('/sw.js').catch(function() {});
    });
  }

  // DOM Init
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() {
      initTheme();
      initMobileDrawer();
    });
  } else {
    initTheme();
    initMobileDrawer();
  }
})();